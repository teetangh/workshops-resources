# Basic-Chess-Engine
Basic Chess Engine using Alpha Beta pruning
