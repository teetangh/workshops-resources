Links for the questions:

**Ciel And Receipt** :
https://www.codechef.com/problems/CIELRCPT

**A and B** :
https://codeforces.com/contest/1278/problem/B

**Binary Palindromes** :
https://codeforces.com/problemset/problem/1251/B