Links for Questions:

**Lonely Integer**:
https://www.hackerrank.com/challenges/lonely-integer/problem

**The Great XOR**:
https://www.hackerrank.com/challenges/the-great-xor/problem

**Make Good**:
https://codeforces.com/contest/1270/problem/C

