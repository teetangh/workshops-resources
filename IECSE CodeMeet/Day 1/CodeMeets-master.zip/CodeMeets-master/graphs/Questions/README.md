Links for the questions:

**Shortest Path Maze** :
https://www.codechef.com/problems/DAY4P2

**Playing With Numbers** :
https://www.codechef.com/ENAU2018/problems/PLYNUM

**Social Network** :
https://www.codechef.com/problems/SNET

